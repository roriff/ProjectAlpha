﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClassLibrary;

public partial class AnObservationPage : System.Web.UI.Page
{
    
    // constant variables PatientID to store the value of the PatientID
    Int32 PatientID;

    // constant variable StaffID to store the value of the Staff performing this observation
    Int32 StaffID;

    // constant variable to store session object UserName declared in the page login if you remember :-)
    string myUserName;

    protected void Page_Load(object sender, EventArgs e)
    {
        //Disabled the butttons that are not meant to be used on this page
        btnAddObservation.Enabled = false;
        btnEditObservation.Enabled = false;
        btnArchiveObservation.Enabled = false;
        txtObservationID.Enabled = false;

        // make the PatientName text disabled as user is not meant to access it
        // it is also set as a read only textbox
        txtPatientName.Enabled = false;

        //ObservationID is -1 as we always add observation , we do not edit them
        //txtObservation.Text = -1 in the text properties
        Int32 ObservationID = Convert.ToInt32(txtObservationID.Text);

        // Use the session object UserName that is being passed between the pages in the server and store it as myUserName
        myUserName = (string)Session["UserName"];

        // get the StaffID as it is relevant for this page by using the session object as a parameter
        StaffID = DisplayCurrentStaffID(myUserName);

        // if we need to display the staffID to the user, we need a textStaffID textbox on the form
        //txtStaffID.Text = Convert.ToString(StaffID); 

        // copy the data from the query string seen in the browser to the textbox txtPatientID
        PatientID = Convert.ToInt32(Request.QueryString["PatientID"]);

        //view the Patient name in the Patient textbox from the session objects FirstName and LastName 
        //they were declared in the SelectedIndex_Changed of the datagrid view
        txtPatientName.Text = (string)Session["FirstName"] + " " + (string)Session["LastName"];
        
        if (IsPostBack != true)
        {

            //if (ObservationID != -1)
           // {
                // display an error message
                
            //}

            //else 
            //{
         
            //}
        }

    }

    public Int32 DisplayCurrentStaffID(string UserName)
    {
        // create an object Staff of type clsStaffCollection
        clsStaffCollection Staff = new clsStaffCollection();

        // create an instance to store the current staff
        clsStaff CurrentStaff = new clsStaff();

        // now store the curent staff  by using the method GetStaffLoginDetails which is of type clsStaffCollection
        CurrentStaff = Staff.GetStaffID(UserName);

        // return the value data of the current staff
        return CurrentStaff.StaffID;

    }

    protected void btnSave_Click(object sender, EventArgs e)
    {

        //create an instance of the clsObservation
        clsObservation ThisObservation = new clsObservation();

        // variable to store any error message
        //string ErrorMessage;

        //test the data entered on the web form by validating each field based on each validation method from the clsObservation
        string WeightErrorMessage = ThisObservation.ValidateWeight(txtWeight.Text);
        string HeightErrorMessage = ThisObservation.ValidateHeight(txtHeight.Text);
        string TemperatureErrorMessage = ThisObservation.ValidateTemperature(txtTemperature.Text);
        string BloodPressureErrorMessage = ThisObservation.ValidateBloodPressure(txtBloodPressure.Text);
        string PulseErrorMessage = ThisObservation.ValidatePulse(txtPulse.Text);
        
        string DateTimeTakenErrorMessage = ThisObservation.ValidateDateTimeTaken(txtDateTimeTaken.Text);
        string PhysicalNotesErrorMessage = ThisObservation.ValidateNotes(txtPhysicalStateNotes.Text);
        string MentalNotesErrorMessage = ThisObservation.ValidateNotes(txtMentalStateNotes.Text);

        if (WeightErrorMessage +
            HeightErrorMessage +
           TemperatureErrorMessage +
           BloodPressureErrorMessage +
           PulseErrorMessage +
           DateTimeTakenErrorMessage +
           PhysicalNotesErrorMessage +
           MentalNotesErrorMessage == "") // if the concatenation of those strings is empty then all validations passed
        {
            // do something with the data add obseravtion or edit it e.g insert or update 

            // save the data by adding  the data to the database
            if (txtObservationID.Text == "-1") // if the Observation is -1 then add the record.....
            {
                
                // create an new instance of the clsObservation
                clsObservation NewObservation = new clsObservation();

                // copy the all the data from the user interface to the object
                NewObservation.ObservationType = Convert.ToString(ddlObservationType.SelectedValue);
                NewObservation.PatientWeight = Convert.ToDouble(txtWeight.Text);
                NewObservation.Height = Convert.ToDouble(txtHeight.Text);
                NewObservation.Temperature = Convert.ToDouble(txtTemperature.Text);
                NewObservation.BloodPressure = txtBloodPressure.Text;
                NewObservation.Pulse = Convert.ToInt32(txtPulse.Text);
                NewObservation.DateTimeTaken = Convert.ToDateTime(txtDateTimeTaken.Text);
                NewObservation.PhysicalStateNotes = txtPhysicalStateNotes.Text;
                NewObservation.MentalStateNotes = txtMentalStateNotes.Text;

                NewObservation.MRIScanImage = FileUpload.FileName;      
                     
                // foreign keys data
                NewObservation.PatientID = PatientID; // PatientID in the query string defined on the page load
                NewObservation.StaffID = StaffID; // StaffID in defined in the page load

                // create a new instance of the clsObservationCollection
                clsObservationCollection NewObservationTable = new clsObservationCollection();

                // insert the new record of the observation table object created above to the database
                NewObservationTable.InsertObservation(NewObservation);
               
            }

            else // update the patient's record as the record is existing already
            {      

            }

            // then return to the main observation page if everything went OK
            Response.Redirect("AnObservation.aspx");
        }
        

        else // in case there are errors while filling the observation form
        {
            //return the error messages one after the other depending on which data entry fails 
            lblWeightMessage.Text = WeightErrorMessage;
            lblHeightMessage.Text = HeightErrorMessage;
            lblTemperatureMessage.Text = TemperatureErrorMessage;
            lblBloodPressureMessage.Text = BloodPressureErrorMessage;
            lblPulseMessage.Text = PulseErrorMessage;
            lblDateTimeTakenMessage.Text = DateTimeTakenErrorMessage;
            lblPhysicalNotesMessage.Text = PhysicalNotesErrorMessage;
            lblMentalNotesMessage.Text = MentalNotesErrorMessage;
        }
    }

    protected void btnDoNotSave_Click(object sender, EventArgs e)
    {
        Response.Redirect("AnObservation.aspx");
    }
    
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("AnObservation.aspx");
    }
  
    protected void btnAddObservation_Click(object sender, EventArgs e)
    {
        // no action here as button is disabled
    }
    protected void btnEditObservation_Click(object sender, EventArgs e)
    {
        // no action here as button is disabled
    }

    protected void btnArchiveObservation_Click(object sender, EventArgs e)
    {
        // no action here as button is disabled
    }

    protected void btnExit_Click(object sender, EventArgs e)
    {
        Response.Redirect("Index.aspx");
    }


}