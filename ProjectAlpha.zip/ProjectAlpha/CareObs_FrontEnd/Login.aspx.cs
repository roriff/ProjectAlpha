﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClassLibrary;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnLogIn_Click(object sender, EventArgs e)
    {
        //create an object of type clsStaffCollection
        clsStaffCollection ThisStaff = new clsStaffCollection();

        // now use the object to test the login using the method TestLogin passing it the arguments from the user interface
        if (ThisStaff.TestHospitalStaffLogin(txtUserName.Text, txtPassword.Text) == true)
        {
            //define from this event a session object to store which will be used in another page
            Session["UserName"] = txtUserName.Text;

            //Redirect to the seller page
            Response.Redirect("Index.aspx");
        }
        else
        {
            lblLoginMessage.Text = " Please enter your correct UserName and Password " +
                                   "<br/>" +
                                   "OR" +
                                   "<br/>" +
                                   "Contact System Admin to be registered first before you can log in ";
        }
    }
}