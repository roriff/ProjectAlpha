﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClassLibrary;

public partial class CareObs : System.Web.UI.MasterPage
{

    // variables to store session object UserName declared in the page login if you remember :-)
    string myUserName;

    protected void Page_Load(object sender, EventArgs e)
    {
        // Use the session  object that is being passed between the pages in the server and store it as myUserName
        myUserName = (string)Session["UserName"];

        // Acknowledge the user  by welcoming him or her
        lblUserName.Text = "Welcome " + DisplayCurrentUser(myUserName);
        

    }

    //This method will display the staff Login Details of the current user of the system
    public string DisplayCurrentUser(string LoginDetails)
    {
        // create an object Staff of type clsStaffCollection
        clsStaffCollection Staff = new clsStaffCollection();

        // create an instance to store the current staff
        clsStaff CurrentStaff = new clsStaff();

        // now store the curent staff  by using the method GetStaffLoginDetails which is of type clsStaffCollection
        CurrentStaff = Staff.GetStaffLoginDetails(LoginDetails);

        // return the value data of the current staff
        return CurrentStaff.StaffLoginDetails;
    }
   

    protected void btnManagePatient_Click(object sender, EventArgs e)
    {
        Response.Redirect("APatient.aspx"); // always redirect to the patient page
    }
    protected void btnManageObservation_Click(object sender, EventArgs e)
    {
        Response.Redirect("AnObservation.aspx"); // redirect to the Observation page
    }
    protected void btnManageTreatment_Click(object sender, EventArgs e)
    {
        Response.Redirect("ATreatment.aspx"); // redirect to the treatment page
    }

    protected void btnLogOut_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx"); // redirect to login page
    }
}
