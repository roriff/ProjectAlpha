﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClassLibrary;

public partial class ATreatmentPage : System.Web.UI.Page
{
    // global variable 
    Int32 PatientID;
    Int32 TreatmentID;

    protected void Page_Load(object sender, EventArgs e)
    {
        //Disabled the butttons that are not meant to be used on this page
        btnAddTreatment.Enabled = false;
        btnEditTreatment.Enabled = false;
        btnArchiveTreatment.Enabled = false;

        txtTreatmentID.Enabled = false;

        // copy the data from the query string seen in the browser to the textbox txtPatientID
        PatientID = Convert.ToInt32(Request.QueryString["PatientID"]);

        if (IsPostBack != true)
        {

            if (PatientID != -1)
            {

                // display the data of this patient on the form
                DisplayPatientTreatment(PatientID);

                // now we know the TreatmentID
                TreatmentID = Convert.ToInt32(txtTreatmentID.Text);

                /*  display the other infos about the treatment given to the patient
                we have just displayed the TreatmentID with the previous method DisplayPatientTreatment */
                DisplayOtherTreatmentInfos(TreatmentID);

            }

            //else // in case the patient doesn't exist  
            //{
            
            //}
        }

    }

    // Method to display the treatment on the form
    void DisplayPatientTreatment(Int32 PatientID)
    {
        //create an an instance of the class clsTPatientColllection
        clsPatientCollection MyTreatment = new clsPatientCollection();

        // create an instance of the class clsPatient
        clsPatient TreatmentToEdit = new clsPatient();

        // get the data for this record
        TreatmentToEdit = MyTreatment.FindPatient(PatientID);

        // display all the treatment infos related to the patient on the form data 
        txtTreatmentID.Text = Convert.ToString(TreatmentToEdit.TreatmentID);
        ddlMedicalCondition.SelectedIndex = Convert.ToInt32(TreatmentToEdit.TreatmentID);
        
        // take the converted integer value of the PatientToEdit TreatmentID 
        //and put it as the index number of the ddlMedicalCondition so it displays the selectedvalue of that index in the ddlMedicalCondition 
        //ddlTreatmentType.SelectedIndex = Convert.ToInt32(TreatmentToEdit.TreatmentID);
        

        //txtMedicationGiven.Text = TreatmentToEdit.MedicationGiven;
        //txtComments.Text = TreatmentToEdit.Comments;
        
    }

    void DisplayOtherTreatmentInfos(Int32 TreatmentID)
    {
        //create an an instance of the class clsTreatmentColllection
        clsTreatmentCollection MyTreatment = new clsTreatmentCollection();

        // create an instance of the class clsTreatment
        clsTreatment TreatmentToEdit = new clsTreatment();

        // get the data for this record
        TreatmentToEdit = MyTreatment.FindPatientTreatment(TreatmentID);

        // display all the treatment infos related to the patient on the form data 
        //txtTreatmentID.Text = Convert.ToString(TreatmentToEdit.TreatmentID);
        //ddlMedicalCondition.SelectedIndex = Convert.ToInt32(TreatmentToEdit.TreatmentID);

       
        //Get the selectedValue of the ddlMedicalCondition and match it to the SelectedIndex 
        ddlTreatmentType.SelectedIndex = Convert.ToInt32(TreatmentToEdit.TreatmentID);
        
        //display the other texts
        txtMedicationGiven.Text = TreatmentToEdit.MedicationGiven;
        txtComments.Text = TreatmentToEdit.Comments;
    }





    protected void btnExit_Click(object sender, EventArgs e)
    {
        Response.Redirect("Index.aspx");
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        Response.Redirect("ATreatment.aspx");
    }

    protected void btnDoNotSave_Click(object sender, EventArgs e)
    {
        Response.Redirect("ATreatment.aspx");
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("ATreatment.aspx");
    }

    protected void btnArchiveTreatment_Click(object sender, EventArgs e)
    {

    }
}