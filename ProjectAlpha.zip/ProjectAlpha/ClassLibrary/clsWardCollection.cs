﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class clsWardCollection
    {
        // Methods that will apply the any ward object created 
    }
}
