﻿namespace CareObs_BackEnd
{
    partial class frmPatientTreatmentReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPatientTreatmentReport = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtMedicalCondition = new System.Windows.Forms.TextBox();
            this.lblMedicalCondition = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblPatientTreatmentReport
            // 
            this.lblPatientTreatmentReport.AutoSize = true;
            this.lblPatientTreatmentReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPatientTreatmentReport.ForeColor = System.Drawing.Color.Blue;
            this.lblPatientTreatmentReport.Location = new System.Drawing.Point(276, 31);
            this.lblPatientTreatmentReport.Name = "lblPatientTreatmentReport";
            this.lblPatientTreatmentReport.Size = new System.Drawing.Size(269, 20);
            this.lblPatientTreatmentReport.TabIndex = 2;
            this.lblPatientTreatmentReport.Text = "PATIENT TREATMENT REPORT";
            // 
            // btnSearch
            // 
            this.btnSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Location = new System.Drawing.Point(530, 84);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(135, 26);
            this.btnSearch.TabIndex = 5;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            // 
            // txtMedicalCondition
            // 
            this.txtMedicalCondition.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMedicalCondition.Location = new System.Drawing.Point(302, 87);
            this.txtMedicalCondition.Name = "txtMedicalCondition";
            this.txtMedicalCondition.Size = new System.Drawing.Size(197, 23);
            this.txtMedicalCondition.TabIndex = 42;
            // 
            // lblMedicalCondition
            // 
            this.lblMedicalCondition.AutoSize = true;
            this.lblMedicalCondition.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMedicalCondition.Location = new System.Drawing.Point(177, 93);
            this.lblMedicalCondition.Name = "lblMedicalCondition";
            this.lblMedicalCondition.Size = new System.Drawing.Size(119, 17);
            this.lblMedicalCondition.TabIndex = 43;
            this.lblMedicalCondition.Text = "Medical Condition";
            // 
            // frmPatientTreatmentReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 371);
            this.Controls.Add(this.lblMedicalCondition);
            this.Controls.Add(this.txtMedicalCondition);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.lblPatientTreatmentReport);
            this.Name = "frmPatientTreatmentReport";
            this.Text = "Patient Treatment Report";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPatientTreatmentReport;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtMedicalCondition;
        private System.Windows.Forms.Label lblMedicalCondition;
    }
}