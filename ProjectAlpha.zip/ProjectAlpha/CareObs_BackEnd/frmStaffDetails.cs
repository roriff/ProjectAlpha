﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassLibrary;

namespace CareObs_BackEnd
{
    public partial class frmStaffDetails : Form
    {


        public frmStaffDetails()
        {
            InitializeComponent();
        }

        private void frmStaffDetails_Load(object sender, EventArgs e)
        {
           /* // Disable the buttons and textboxes that need to be disabled
            txtStaffID.Enabled = false;
            txtStaffID.Text = "-1";

            //convert the value in textStaffID to integer
            Int32 StaffID = Convert.ToInt32(txtStaffID.Text);

            if (txtStaffID.Text != "-1")
            {
                //clear the textbox first
                //txtStaffID.Text = "";

                // display the data of this patient on the form
                //DisplayStaff(StaffID);
            }
            */
        }
           
        
        // Method to display the staff on the form
        public void DisplayStaffID(Int32 StaffID)
        {
            //clear the txtStaffID.Text first 
            txtStaffID.Text = Convert.ToString(StaffID);
            txtStaffID.Enabled = false;

        }


        // Method to display the staff on the form
        public void DisplayStaff(Int32 StaffID)
        {

            //create an an instance of the class clsStaffColllection
             clsStaffCollection MyStaff = new clsStaffCollection();

             // create an instance of the class clsPatient
             clsStaff StaffToEdit = new clsStaff();

             // get the data for this record
             StaffToEdit = MyStaff.FindStaff(StaffID);


             // display all the staff data found on the form by putting the value of the StaffToEdit values rom the database
             //and putting it in the textboxes
             //txtStaffID.Text = ""; // first clear whatever is in the txtStaffID textbox first
             //txtStaffID.Text = Convert.ToString(StaffToEdit.StaffID);
             
             txtTitle.Text = StaffToEdit.Title;
             txtFirstName.Text = StaffToEdit.FirstName;
             txtLastName.Text = StaffToEdit.LastName;
             txtGender.Text = StaffToEdit.Gender;
             txtUserName.Text = StaffToEdit.UserName;
             txtPassword.Text = StaffToEdit.Password;
             txtIndustrySector.Text = StaffToEdit.IndustrySector;
             txtPosition.Text = StaffToEdit.Position;
             txtQualifications.Text = StaffToEdit.HighestQualification;

             txtStreet.Text = StaffToEdit.Street;
             txtTown.Text = StaffToEdit.Town;
             txtCounty.Text = StaffToEdit.County;
             txtPostCode.Text = StaffToEdit.PostCode;
             txtLandlineNo.Text = StaffToEdit.LandlineNo;
             txtMobileNo.Text = StaffToEdit.MobileNo;
             txtEmailAddress.Text = StaffToEdit.EmailAddress;

             txtDateJoined.Text = Convert.ToString(StaffToEdit.DateJoined);
             txtDateLeft.Text = Convert.ToString(StaffToEdit.DateLeft);
            
        }


        

        private void btnSave_Click(object sender, EventArgs e)
        {

            //create an instance of the clsStaffCollection
            clsStaff ThisStaff = new clsStaff();

            // variable to store any error message
            //string ErrorMessage;

            //test the data entered on the windows form by validating each field based on each validation method from the clsStaff
            string TitleErrorMessage = ThisStaff.ValidateTitleString(txtTitle.Text);
            string FirstNameErrorMessage = ThisStaff.ValidateFirstName(txtFirstName.Text);
            string LastNameErrorMessage = ThisStaff.ValidateLastName(txtLastName.Text);
            string GenderErrorMessage = ThisStaff.ValidateGender(txtGender.Text);
            string UserNameErrorMessage = ThisStaff.ValidateUserName(txtUserName.Text);
            string PasswordErrorMessage = ThisStaff.ValidatePassword(txtPassword.Text);
            string IndustrySectorErrorMessage = ThisStaff.ValidateIndustrySector(txtIndustrySector.Text);
            string PositionErrorMessage = ThisStaff.ValidatePosition(txtPosition.Text);
            string QualificationErrorMessage = ThisStaff.ValidateQualification(txtQualifications.Text);
            string StreetErrorMessage = ThisStaff.ValidateStreet(txtStreet.Text);
            string TownErrorMessage = ThisStaff.ValidateTown(txtTown.Text);
            string CountyErrorMessage = ThisStaff.ValidateCounty(txtCounty.Text);
            string PostCodeErrorMessage = ThisStaff.ValidatePostCode(txtPostCode.Text);
            string LandlineNoErrorMessage = ThisStaff.ValidateLandlineNo(txtLandlineNo.Text);
            string MobileNoErrorMessage = ThisStaff.ValidateMobileNo(txtMobileNo.Text);
            string EmailAddressErrorMessage = ThisStaff.ValidateEmail(txtEmailAddress.Text);

            // compare DateJoined and DadteLeft so joining company always takes place before leaving company
            string DateJoinedErrorMessage = ThisStaff.ValidateDateJoined(txtDateJoined.Text);
            string DateLeftErrorMessage = ThisStaff.ValidateDateLeft(txtDateLeft.Text);
            string DateErrorMessage = ThisStaff.ValidateDateJoined_DateLeft(txtDateJoined.Text, txtDateLeft.Text);
            

            if ( TitleErrorMessage +
                 FirstNameErrorMessage +
                 LastNameErrorMessage +
                 GenderErrorMessage +
                 UserNameErrorMessage +
                 PasswordErrorMessage +
                 IndustrySectorErrorMessage +
                 PositionErrorMessage +
                 QualificationErrorMessage +
                 StreetErrorMessage +
                 TownErrorMessage +
                 CountyErrorMessage +
                 PostCodeErrorMessage +
                 LandlineNoErrorMessage +
                 MobileNoErrorMessage +
                 EmailAddressErrorMessage +
                 DateJoinedErrorMessage +
                 DateLeftErrorMessage +
                 DateErrorMessage  == "") // if the concatenation of those strings is empty then all validations passed
            {
                // do something with the data add staff or edit staff e.g insert or update 

                // save the data by adding  the data to the database
                if (txtStaffID.Text == "-1") // if the StaffID is -1 then insert the record.....
                {
                    // create an new instance of the clsStaff
                    clsStaff NewStaff = new clsStaff();

                    // copy the all the data from the user interface to the object
                    NewStaff.Title = txtTitle.Text; 
                    NewStaff.FirstName = txtFirstName.Text;
                    NewStaff.LastName = txtLastName.Text;
                    NewStaff.Gender = txtGender.Text;
                    NewStaff.UserName = txtUserName.Text;
                    NewStaff.Password = txtPassword.Text;
                    NewStaff.IndustrySector = txtIndustrySector.Text;
                    NewStaff.Position = txtPosition.Text;
                    NewStaff.HighestQualification= txtQualifications.Text;

                    NewStaff.Street = txtStreet.Text;
                    NewStaff.Town = txtTown.Text;
                    NewStaff.County = txtCounty.Text;
                    NewStaff.PostCode = txtPostCode.Text;
                    NewStaff.LandlineNo = txtLandlineNo.Text;
                    NewStaff.MobileNo = txtMobileNo.Text;
                    NewStaff.EmailAddress = txtEmailAddress.Text;

                    NewStaff.DateJoined = Convert.ToDateTime(txtDateJoined.Text);
                    NewStaff.DateLeft = Convert.ToDateTime(txtDateLeft.Text);


                    // create a new instance of the clsStaffCollection
                    clsStaffCollection NewStaffTable = new clsStaffCollection();

                    // insert the new record of the staff table object created above to the database
                    NewStaffTable.InsertStaff(NewStaff);
                    
                }

                else // update the staff record as the record is existing already
                {
                    // this is an existing record that we can update
                    //creatte a new instance of clsStaff
                    clsStaff ExistingStaff = new clsStaff();

                    //copy the data from the user interface to the object created above so it can be sent to the database
                    ExistingStaff.StaffID = Convert.ToInt32(txtStaffID.Text);
                    ExistingStaff.Title = txtTitle.Text;
                    ExistingStaff.FirstName = txtFirstName.Text;
                    ExistingStaff.LastName = txtLastName.Text;
                    ExistingStaff.Gender = txtGender.Text;
                    ExistingStaff.UserName = txtUserName.Text;
                    ExistingStaff.Password = txtPassword.Text;
                    ExistingStaff.IndustrySector = txtIndustrySector.Text;
                    ExistingStaff.Position = txtPosition.Text;
                    ExistingStaff.HighestQualification = txtQualifications.Text;

                    ExistingStaff.Street = txtStreet.Text;
                    ExistingStaff.Town = txtTown.Text;
                    ExistingStaff.County = txtCounty.Text;
                    ExistingStaff.PostCode = txtPostCode.Text;
                    ExistingStaff.LandlineNo = txtLandlineNo.Text;
                    ExistingStaff.MobileNo = txtMobileNo.Text;
                    ExistingStaff.EmailAddress = txtEmailAddress.Text;

                    ExistingStaff.DateJoined = Convert.ToDateTime(txtDateJoined.Text);
                    ExistingStaff.DateLeft = Convert.ToDateTime(txtDateLeft.Text);

                    //create a new instance of the clsStaffCollection
                    clsStaffCollection NewStaffTable = new clsStaffCollection();

                    //update the existing record
                    NewStaffTable.UpdateStaff(ExistingStaff);


                }

                // then update list box of staff to see the newly added staff
                frmStaff StaffManager = new frmStaff();
                //set the mdi parent of the created form to the main form 
                StaffManager.MdiParent = this.Parent.Parent as mdiCareObservation;
                //make the form visible
                StaffManager.Visible = true;
                //then update the list 
                StaffManager.FilllstStaff();

                // then close this form and return to the main form if everything went OK
                this.Close(); // just leave the form

            }
 

            else // in case there are errors while filling the staffform
            {
                // make the errors visible on the form first as they were set to be invisible in the original form properties
                lblTitleError.Visible = true;
                lblFirstNameError.Visible = true;
                lblLastNameError.Visible = true;
                lblGenderError.Visible = true;
                lblUserNameError.Visible = true;
                lblPasswordError.Visible = true;
                lblIndustrySectorError.Visible = true;
                lblPositionError.Visible = true;
                lblQualificationError.Visible = true;

                lblStreetError.Visible = true;
                lblTownError.Visible = true;
                lblCountyError.Visible = true;
                lblPostCodeError.Visible = true;
                lblLandlineNoError.Visible = true;
                lblMobileNoError.Visible = true;
                lblEmailAddressError.Visible = true;

                lblDateJoinedError.Visible = true; ;
                lblDateLeftError.Visible = true;
                lblDateJoinedDateLeftError.Visible = true;

                //return the error messages one after the other depending on which data entry fails 
                lblTitleError.Text = TitleErrorMessage;
                lblFirstNameError.Text = FirstNameErrorMessage;
                lblLastNameError.Text = LastNameErrorMessage;
                lblGenderError.Text = GenderErrorMessage;
                lblUserNameError.Text = UserNameErrorMessage;
                lblPasswordError.Text = PasswordErrorMessage;
                lblIndustrySectorError.Text = IndustrySectorErrorMessage;
                lblPositionError.Text = PositionErrorMessage;
                lblQualificationError.Text = QualificationErrorMessage;

                lblStreetError.Text = StreetErrorMessage;
                lblTownError.Text = TownErrorMessage;
                lblCountyError.Text = CountyErrorMessage;
                lblPostCodeError.Text = PostCodeErrorMessage;
                lblLandlineNoError.Text = LandlineNoErrorMessage;
                lblMobileNoError.Text = MobileNoErrorMessage;        
                lblEmailAddressError.Text = EmailAddressErrorMessage;

                lblDateJoinedError.Text = DateJoinedErrorMessage;
                lblDateLeftError.Text = DateLeftErrorMessage;
                lblDateJoinedDateLeftError.Text = DateErrorMessage; // to display the message between DateJoined and DateLeft
                
            }
        }


        private void btnDoNotSave_Click(object sender, EventArgs e)
        {
            string Message = "Are you sure you don't want to save this record?";
            string Title = "Confirm Operation";
            DialogResult Result;
            Result = MessageBox.Show(Message, Title, MessageBoxButtons.YesNo);
            if (Result == System.Windows.Forms.DialogResult.Yes)
            {
                // then update list box of staff to see the newly added staff
                frmStaff StaffManager = new frmStaff();
                //set the mdi parent of the created form to the main form 
                StaffManager.MdiParent = this.Parent.Parent as mdiCareObservation;
                //make the form visible
                StaffManager.Visible = true;
                //then update the list 
                StaffManager.FilllstStaff();

                // then close this form and return to the main form if everything went OK
                this.Close(); // just leave the form

            }

            
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            

            // then update list box of staff to see the newly added staff
            frmStaff StaffManager = new frmStaff();
            //set the mdi parent of the created form to the main form 
            StaffManager.MdiParent = this.Parent.Parent as mdiCareObservation;
            //make the form visible
            StaffManager.Visible = true;
            //then update the list 
            StaffManager.FilllstStaff();

            // then close this form and return to the main form if everything went OK
            this.Close(); // just leave the form
        }


        private void lblDateJoinedDateLeftError_Click(object sender, EventArgs e)
        {
            // no code here
        }

        private void lblPostCodeError_Click(object sender, EventArgs e)
        {
          // no code here
        }
    }
}
