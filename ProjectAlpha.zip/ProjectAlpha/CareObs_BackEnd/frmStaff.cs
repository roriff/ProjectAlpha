﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Web.UI.WebControls;
using ClassLibrary;

namespace CareObs_BackEnd
{
    public partial class frmStaff : Form
    {

        public static class StaffIDSession
        {
        //variable to store the the primary key of the staff
        // static Int32 StaffID = Convert.ToInt32(lstStaff.SelectedValue);
        }

        public frmStaff()
        {
            InitializeComponent();
        }

        private void frmStaff_Load(object sender, EventArgs e)
        {

            // Fill the list of staff
            FilllstStaff();
        }

        

        public void FilllstStaff()
        {
            lstStaff.DataSource = null;// clear list box of data
            clsStaffCollection MyStaff = new clsStaffCollection();// new object
            MyStaff.BackEnd_Staff_SelectAll();// run query
            lstStaff.DataSource = MyStaff.StaffListDetails;// data source list<>
            lstStaff.DisplayMember = "StaffDetails";// display
            lstStaff.ValueMember = "StaffID";// primary key
            lstStaff.SelectedIndex = -1;// no record selected

            // variable to store the count of records in the object 
            Int32 recordCount = MyStaff.Count;

            // Tell the user how many records were found
            lblStaffMessage.Text = "There are  " + recordCount + " Staff found and they are sorted alphabetically by their Last Name.";

        }

        private void FilllstStaff_SearchByName()
        {
            lstStaff.DataSource = null;// clear list box of data
            clsStaffCollection MyStaff = new clsStaffCollection();// new object
            MyStaff.FindStaffByName(txtStaffName.Text,txtStaffName.Text);// run query
            lstStaff.DataSource = MyStaff.StaffListDetails;// data source list<>
            lstStaff.DisplayMember = "StaffDetails";// display
            lstStaff.ValueMember = "StaffID";// primary key
            lstStaff.SelectedIndex = -1;// no record selected

            // variable to store the count of records in the object 
            Int32 recordCount = MyStaff.Count;

            // Tell the user how many records were found
            lblStaffMessage.Text = "There are  " + recordCount + " Staff found and they are sorted alphabetically by their Last Name.";

        }

        // Filter all staff to be displayed in the listbox based on their fullname
        public Int32 ViewAllStaff(string firstNameFilter, string lastNameFilter)
        {
            //Declare the variables that will be visible in the list
            Int32 staffID;
            //string gender;
            string firstName;
            string lastName;
            string position;

            //create an instance of the class clsStaffCollection
            clsStaffCollection MyStaff = new clsStaffCollection();

            // apply the filter by full name
            MyStaff.FindStaffByName(firstNameFilter, lastNameFilter);

            // variable to store the count of records in the object 
            Int32 recordCount = MyStaff.Count;

            // variable to store the index for the loop
            Int32 index = 0;

            // clear any data off the list first
            lstStaff.Items.Clear();

            // loop while there are still some records to process
            while (index < recordCount)
            {
                staffID = MyStaff.StaffList[index].StaffID; // get the primary key of the staff
                //gender = MyStaff.StaffList[index].Gender;//get the staff's gender
                firstName = MyStaff.StaffList[index].FirstName;//get the staff's firstname
                lastName = MyStaff.StaffList[index].LastName;//get the staff's LastName
                position = MyStaff.StaffList[index].Position;
                // create a new entry for the listbox in the UI
                ListItem newEntry = new ListItem(
                                                 firstName + " " +
                                                 lastName + " ,  "+
                                                 position, Convert.ToString(staffID)
                                                 );

                // make sure that StaffID is always assigned as the value of the member 
                //as a windows form doesn't do it automatically as in a web form
                lstStaff.ValueMember = "staffID";

                // add the staff data collected from newEntry to the list
                lstStaff.Items.Add(newEntry);

                // move the index to the next record for the loop to continue
                index++;
            }

            // Tell the user how many records were found
            lblStaffMessage.Text = "There are  " + recordCount + " Staff found and they are sorted alphabetically by their Last Name.";

            // return the count of the records found
            return recordCount;

        }


        private void btnSearch_Click(object sender, EventArgs e)
        {

            // display only the result  that match the search filter in the listbox
            FilllstStaff_SearchByName();

            // clear all the texts in the textfield
            txtStaffName.Text = "";

            // tell the user what data to enter in the textfield
            txtStaffName.Text = "Enter staff first or last name";
        }

        private void btnDisplayAllStaff_Click(object sender, EventArgs e)
        {
            // display all the staff as in the load of the page
            FilllstStaff();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // create a new object of type
            frmStaffDetails StaffDetailsManager = new frmStaffDetails();

            //set the mdi parent of the created form to the main form 
            StaffDetailsManager.MdiParent = this.Parent.Parent as mdiCareObservation;

            //make the form visible
            StaffDetailsManager.Visible = true;

            StaffDetailsManager.DisplayStaffID(-1); // display a form with StaffID = -1

        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            // if something has been selected meaning selected index is not -1
            if(lstStaff.SelectedIndex != -1)             
            {
                try
                {
                    //variable to store the the primary key of the staff
                    Int32 staffID = Convert.ToInt32(lstStaff.SelectedValue);

                    // create a new object of type
                    frmStaffDetails StaffDetailsManager = new frmStaffDetails();

                    //set the mdi parent of the created form to the main form 
                    StaffDetailsManager.MdiParent = this.Parent.Parent as mdiCareObservation;

                    //make the form visible
                    StaffDetailsManager.Visible = true;

                    StaffDetailsManager.DisplayStaffID(staffID);// function to display the record ID
                    StaffDetailsManager.DisplayStaff(staffID); // function to display the record detail

                    this.Close();// then close this form
                }

                catch
                {
                }

            }

            else
            {
                // display error message
                lblStaffMessage.Text = " You must select a staff from the list first to be able to edit staff.";
            }

        }

        private void btnArchive_Click(object sender, EventArgs e)
        {
            
                // message to user
                lblStaffMessage.Text = "Select a member of staff from the list and archive him/her."; string Message = "Are you sure you want to Archive this record?";
               
                string Title = "Confirm Archive Operation";
                DialogResult Result;
                Result = MessageBox.Show(Message, Title, MessageBoxButtons.YesNo);
                if (Result == System.Windows.Forms.DialogResult.Yes)
                {
                    // do something to archive the data with a stored procedure
                }
            }
        

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();// Close this form
        }

       
    }
}
